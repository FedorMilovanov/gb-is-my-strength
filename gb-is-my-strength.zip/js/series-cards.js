/* series-cards.js — JS-инжектор серийных карточек (AUDIT_10_OF_10 → NAV-11.1)
 *
 * Использование в HTML:
 *   <nav data-series-cards="nagornaya" aria-label="Все части серии"></nav>
 *
 * Источник данных: /data/series.json
 */
(function () {
  'use strict';
  function escHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function escAttr(s) { return escHtml(s).replace(/`/g, '&#96;'); }

  var hosts = document.querySelectorAll('[data-series-cards]');
  if (!hosts.length) return;
  fetch('/data/series.json').then(function (r) { return r.ok ? r.json() : null; }).then(function (data) {
    if (!data) return;
    hosts.forEach(function (host) {
      var seriesId = host.dataset.seriesCards;
      var series = data[seriesId];
      if (!series) return;
      var currentPath = decodeURIComponent(location.pathname).replace(/\/+$/, '/');
      host.innerHTML = series.parts.map(function (p) {
        /* Bug #37: slugs are already valid path segments (ASCII or Cyrillic);
           encodeURIComponent would encode Cyrillic breaking comparison with
           location.pathname which browsers return decoded. */
        var url = '/' + seriesId + '/' + p.slug + '/';
        var current = currentPath === url;
        var badge = current ? 'Вы здесь'
                  : p.status === 'draft'   ? 'В разработке'
                  : p.status === 'planned' ? 'Скоро'
                  : '';
        var inner = '' +
          '<span class="series-card__num">Часть ' + escHtml(p.n) + '</span>' +
          '<h3 class="series-card__title">' + escHtml(p.title) + '</h3>' +
          '<span class="series-card__time">' + escHtml(p.readingTime) + ' мин</span>' +
          (badge ? '<span class="series-card__badge">' + badge + '</span>' : '');
        return current
          ? '<div class="series-card is-current" aria-current="page">' + inner + '</div>'
          : '<a class="series-card" href="' + escAttr(url) + '">' + inner + '</a>';
      }).join('');
    });
  }).catch(function () {});
})();
