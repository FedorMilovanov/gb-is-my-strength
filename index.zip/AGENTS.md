# AGENTS.md — инструкции для Kilo / AI-ассистентов

Этот файл читается Kilo автоматически при старте сессии в этом репозитории.

---

## Атрибуция — Редактор: Фёдор Милованов

На сайте Фёдор Милованов является **редактором**, а не «автором» в традиционном смысле: он задаёт направление, редактирует текст, исправляет неточности и собирает информацию при помощи ИИ.

### Правило: нигде не писать просто «Автор» применительно к Фёдору в контексте статьи.

| Тип контента | Byline (в `<header>`) | author-card-label | Мелкий футер серий |
|---|---|---|---|
| Авторская статья (Тип A/B) | `Редактор: Фёдор Милованов` | `Редактор` | `Ред.: Фёдор Милованов` |
| Перевод (Тип C) | `Редакция перевода: Фёдор Милованов` | `Редакция перевода` | — |

### Обязательные HTML-паттерны

**Byline в `<header class="article-header">`** (Тип A/B):
```html
<p class="article-byline"><span class="article-byline__strong">Редактор: Фёдор Милованов</span></p>
```

**Byline** (Тип C — перевод):
```html
<p class="article-byline"><span class="article-byline__strong">Редакция перевода: Фёдор Милованов</span></p>
```

**Author card** в `<article>` перед `.sources-block` / `.reading-list` (Тип A/B):
```html
<aside class="author-card">
  <div aria-hidden="true" class="author-card-icon">ФМ</div>
  <div class="author-card-body">
    <div class="author-card-label">Редактор</div>
    <div class="author-card-name">Фёдор Милованов</div>
    <p class="author-card-desc">
      Редактор проекта «Господь Бог — Сила Моя», Санкт-Петербург.
      Фёдор Милованов задаёт направление, редактирует мысли, исправляет неточности
      и собирает материал при помощи ИИ.
      <a href="../../about/">Об авторе →</a>
    </p>
  </div>
</aside>
```

**Author card** (Тип C — перевод):
```html
<aside class="author-card">
  <div aria-hidden="true" class="author-card-icon">ФМ</div>
  <div class="author-card-body">
    <div class="author-card-label">Редакция перевода</div>
    <div class="author-card-name">Фёдор Милованов</div>
    <p class="author-card-desc">
      Первичный перевод — ИИ. Редактура богословской и терминологической точности,
      исправление ошибок, отсечение неверифицированных цитат — авторские.
      <a href="../../about/">Об авторе →</a>
    </p>
  </div>
</aside>
```

**Мелкий футер частей серии** (нагорная и подобные):
```html
<p style="font-size:.78rem; color:#8a7968;">Ред.: Фёдор Милованов</p>
```

### Мета-теги

- Тип A/B: `<meta name="author" content="Фёдор Милованов">` + `<meta property="article:author" content="Фёдор Милованов">`
- Тип C: `<meta name="author" content="Имя Автора Оригинала">` + `<meta name="translator" content="Фёдор Милованов">`

### Карточки на главной и в каталоге

```html
<span class="h-meta-author">Редактор: Фёдор Милованов</span>
```

---

## Про проект

- **Название:** Господь Бог — Сила Моя
- **Тип:** статический сайт на GitHub Pages
- **URL:** https://gospod-bog.ru/
- **Стек:** чистый HTML + CSS + JS, без сборщиков
- **Деплой:** автоматический — push в `main` → GitHub Pages обновляется через ~1 минуту

## Структура

```
/
├── index.html          # главная (список публикаций)
├── 404.html
├── articles/           # статьи (по папке на каждую)
│   ├── kod-da-vinchi/index.html
│   ├── krajne-li-isporcheno-serdce/index.html
│   └── hermenevticheskaya-otsenka-hristotsentrichnoy-germenevtiki/index.html
├── css/site.css        # единый CSS всего сайта (~5800 строк, 40 секций)
├── js/site.js          # единый JS всего сайта
├── js/bookmark-engine.js
├── images/, assets/    # медиа

> ⚠️ **Контентные изображения отсутствуют в репозитории** — файлы `ieremia-*.webp`, `hero-kod-da-vinchi.jpg`, `ieremia-cover.jpg`, `hermenevtika-preview.webp` нужно загружать отдельно в `/images/`. OG-изображения Нагорной проповеди (`og-nagornaya-propoved*.webp`) и `og-preview.jpg` присутствуют. До загрузки статейных OG-картинок в `og:image`/`twitter:image` статей `kod-da-vinchi`, `krajne-li-isporcheno-serdce` и `hermenevticheskaya` временно стоит `og-preview.jpg` — вернуть оригинальные URL после загрузки.
├── feed.xml, sitemap.xml, robots.txt
```

Оглавление секций CSS находится в шапке `css/site.css` (строки 1–49).

---

## Правила работы

### Коммиты
- Использовать **Conventional Commits**: `fix:`, `feat:`, `style:`, `refactor:`, `docs:`, `chore:`
- Одна логическая правка = один коммит
- Сообщения по-русски или по-английски (единообразно в рамках коммита)
- НЕ использовать "Add files via upload" — только через `git push`

### Правки JS

- Основной файл — `js/site.js`. Модули пронумерованы, каждый в своём IIFE.
- **ОБЯЗАТЕЛЬНО после любой правки `js/site.js` перед коммитом:**
  ```
  node --check js/site.js
  ```
  Если команда выводит ошибку — исправить до коммита. Синтаксическая ошибка в `site.js` убивает **все** JS-модули на сайте разом (TOC, тема, изображения, tooltips и т.д.).
- Не дублировать тела обработчиков — при редактировании проверять, что старый блок удалён полностью.

### Правки CSS
- Основной файл — `css/site.css`. Файл `css/site.css.bak` — резервная копия, не трогать и не коммитить (в `.gitignore`)
- Ориентироваться по секциям из шапки файла
- Все изменения должны учитывать и светлую, и тёмную тему (`html.dark { ... }`)

### Git
- Ветка по умолчанию — `main`
- Работать напрямую в `main` для мелких правок (CSS, тексты)
- Для крупных фич — создавать ветку `feature/...` и PR
- Перед началом работы: `git pull`
- После правок: `git add . && git commit -m "..." && git push`

### Что НЕ трогать без явного разрешения
- `sitemap.xml`, `feed.xml`, `robots.txt` — SEO-инфраструктура
- `google*.html`, `yandex*.html` — верификация поисковиков
- Разметка JSON-LD в `<head>` — структурированные данные
- Счётчик Yandex.Metrika

---

## Универсальные элементы (правим на ВЕСЬ сайт сразу)

У сайта есть общие «кросс-страничные» UI-элементы. Если меняем их — меняем централизованно в `css/site.css` (и, если нужно, в `js/site.js`), проверяем во ВСЕХ статьях и на главной.

Актуальные статьи для проверки:
- `articles/kod-da-vinchi/index.html`
- `articles/krajne-li-isporcheno-serdce/index.html`
- `articles/hermenevticheskaya-otsenka-hristotsentrichnoy-germenevtiki/index.html`
- плюс `index.html` (главная)

| Элемент | Где в CSS | Правила |
|---|---|---|
| **Хлебные крошки** (`.breadcrumb`) | секция 06 | Без SVG-домика — только текст «Главная». Длинный заголовок — переносится на следующую строку (`white-space: normal`), НЕ обрезается эллипсисом. Подчёркивание hover анимированное. |
| **Тема день/ночь** (`.theme-toggle`) | секция theme + `:root`/`html.dark` | **СВЕТЛАЯ ТЕМА ПО УМОЛЧАНИЮ.** Логика: если `localStorage === 'dark'` — тёмная; иначе — светлая. Кнопка `#themeToggle` расположена в `site.css` через `.theme-toggle { top: calc(clamp(48px,6.5vw,100px) - 13px); }` — **НЕ ДОБАВЛЯТЬ inline `style="top:..."` на кнопку в HTML**, это сломает выравнивание по хлебным крошкам. |
| **TOC sidebar** (`.toc-link`) | секция 15 | Rail без точек. Активный пункт — утолщённый `border-left` цвета `--accent`. H3 — `padding-left: 28px`. |
| **TOC bottom sheet** (`.btoc-nav`) | секция 17 | Тот же Rail-язык. Генерится в `js/site.js`. |
| **Drop-cap первый абзац** (`.drop-cap`) | секция 30 | Автоматически навешивается в `js/site.js` на первый `<p>` в каждой статье. **Не применяется к Типу C (Переводы)** — JS проверяет `page.section`. Если класс уже есть в HTML — JS пропускает. |
| **Article End Block** (`.article-end-block`) | секция 38 | Инжектируется JS (модуль 27) автоматически во все статьи. **НЕ добавлять вручную в HTML.** Не добавлять `<div class="share-block">`, `<div class="print-btn-wrap">` или инлайн-блоки SDG/крест в HTML статей — всё это мёртвый код. |
| **Progress bar** (`#reading-progress`) | секция 18 | 2px, цвет `--accent`. |
| **Image viewer** (`.img-viewer`) | секция image viewer | `js/site.js` — универсальный, работает через `.article-figure img`. **НЕ создавать отдельный inline lightbox в HTML статей** — это мёртвый код. |

### Чеклист при правке универсального элемента
1. Изменил в `css/site.css` — проверил в **каждой** статье из списка выше + на главной.
2. HTML-разметка одинакова во всех статьях? Если в новой статье будет отличаться — это баг.
3. Проверил **обе темы** (light + `html.dark`).
4. Проверил мобильный брейкпоинт (≤ 560 px) и планшетный (≤ 820 px).
5. Если добавил новое взаимодействие — обновил `js/site.js` одним общим обработчиком.
6. После правки `js/site.js` — запустил `node --check js/site.js`.

---

## Паттерн новой статьи — Article End Block

Блок «Поделиться / Распечатать + SDG + крест» **инжектируется автоматически** модулем 27 (`js/site.js`) на всех страницах с `page.type === 'article'`.

### Что НЕ нужно добавлять в HTML новой статьи:
```html
<!-- ❌ НЕ ДОБАВЛЯТЬ — это мёртвый код, JS удалит их: -->
<div class="share-block">...</div>
<div class="print-btn-wrap">...</div>
<div style="display:flex; flex-direction:column; ...">
  <span class="sdg">Soli Deo Gloria</span>
  <svg ...><!-- крест --></svg>
</div>
```

### Правильная структура конца `<article>` новой статьи:
```html
<article>
  <!-- ... основной текст ... -->

  <!-- ПОСЛЕДНИЙ параграф основного текста -->
  <p>...</p>

  <!-- ← сюда JS вставит .article-end-block автоматически -->

  <!-- Источники / литература (если есть) -->
  <div class="sources-block">...</div>
  <!-- или -->
  <section class="reading-list">...</section>
  <!-- или -->
  <p class="translation-note">...</p>

</article>
```

### Как работает инжектор (модуль 27):
1. Ищет первый из: `.sources-block`, `.reading-list`, `.translation-note`, `.article-footer`
2. Вставляет `.article-end-block` перед ним через `insertBefore`
3. Если ни один не найден — аппендит в конец `<article>`
4. Удаляет старые `.share-block`, `.print-btn-wrap` и инлайн-SDG блоки

---

## FAQ-компонент (эталон 2025)

Стандартная разметка для ВСЕХ новых статей. Не использовать `onclick` на `<div>` — только `<button>` с `aria-expanded`.

### Разметка одного вопроса (copy-paste):
```html
<h2 id="sec-faq">Часто задаваемые вопросы</h2>

<div class="faq-accordion">

  <div class="faq-accordion__item">
    <button class="faq-accordion__q" aria-expanded="false">
      Текст вопроса?
      <span class="faq-accordion__icon" aria-hidden="true"></span>
    </button>
    <div class="faq-accordion__body">
      <div class="faq-accordion__body-inner">
        Текст ответа.
      </div>
    </div>
  </div>

  <!-- Добавляй faq-accordion__item-блоки по тому же шаблону -->

</div>
```

### Правила:
- `<button>` обязателен — `<div onclick>` запрещён (нет доступности с клавиатуры).
- `aria-expanded="false"` ставится в HTML; JS переключает его при клике автоматически (mod. FAQ ACCORDION в `site.js`).
- `<span class="faq-accordion__icon" aria-hidden="true">` — **пустой**, иконка-крест отрисована через `::before`/`::after` в CSS.
- `<div class="faq-accordion__body-inner">` — **обязателен** внутри `.faq-accordion__body`; без него grid-анимация не работает.
- Текст вопроса — прямо в `<button>`, без лишних `<span>`.
- В `id="sec-faq"` заголовка используй `sec-faq` если раздел в навигации TOC; `spravka` — если отдельная справочная секция после основного текста.
- JSON-LD `FAQPage` в `<head>` нужно синхронизировать с HTML-вопросами вручную.

### Как работает анимация (CSS):
- `.faq-accordion__body` — `display:grid; grid-template-rows: 0fr` → `1fr` (переход без ограничения по высоте).
- `.faq-accordion__body-inner` — `overflow:hidden` + анимация `padding-bottom`.
- Анимация отключается при `prefers-reduced-motion`.

### Что НЕ делать:
```html
<!-- ❌ Старая разметка — ЗАПРЕЩЕНА -->
<div class="faq-accordion__item" onclick="this.classList.toggle('open')">
  <div class="faq-accordion__q">
    <span>Вопрос?</span>
    <div class="faq-accordion__icon">+</div>   <!-- текстовый + -->
  </div>
  <div class="faq-accordion__body">Ответ.</div>  <!-- без inner-wrapper -->
</div>
```

---

## Архитектура квиза (эталон — КДВ)

Статья `kod-da-vinchi` является эталоном разметки квиза. Структура обязательна. Статья `krajne-li-isporcheno-serdce` — эталон с бонусным раундом.

```html
<div class="quiz-wrapper" id="quizWrapper">
  <!-- Launch overlay: блюр + кнопка "Начать тест" -->
  <div class="quiz-overlay" id="quizOverlay">
    <button class="quiz-launch-hero" id="quizLaunch" type="button">
      <div class="quiz-launch-icon"><!-- SVG play --></div>
      <span class="quiz-launch-label">Начать тест</span>
      <span class="quiz-launch-hint">N вопросов · сразу узнаете счёт</span>
    </button>
  </div>
  <!-- Quiz content: скрыт до запуска -->
  <div id="quizMain" class="quiz-main--hidden">
    <div id="quizBody">...</div>
    <div class="quiz-result" id="quizResult" style="display:none">...</div>
    <div class="quiz-score" id="quizScore" style="display:none">...</div>
  </div><!-- /quizMain -->
</div>
```

**Правила:**
- `#quizResult` и `#quizNext` — `style="display:none"` по умолчанию в HTML.
- `qFocus` / `quizBonusFocus` — показывается **только при неправильном ответе**, не при рендере вопроса.
- `animateCountNum()` — для числового счёта в `#quizResultScore` (выводит «7», а не «Результат: 7 из 10»).
- `animateCount(el, target, total, duration)` — для legacy `#quizScoreBadge` (выводит «Результат: X из Y»).
- Поле `answer` в вопросах — **индекс правильного ответа** в массиве `options` (нумерация с 0). Не путать с полем `correct`, которое не используется.
- Поле `focus` — id якоря раздела для ссылки «Перечитать раздел» в режиме разбора ошибок. Необязательное.
- `passingMode` — мёртвое поле, **не добавлять** в конфиг квиза.
- `quizShare` — шарит результат со счётом через `SiteShare.open()` с подменой заголовка.
- `getScoreBucket(sc, total, scoresArr)` — массив `scoresArr` **должен быть отсортирован по убыванию `.min`**.
- **Разбор ошибок (Review mode)** — инжектируется автоматически в JS, HTML не требует изменений. Кнопка «Разобрать ошибки (N)» появляется после теста только если есть ошибки. Режим: каждый неправильный вопрос снова, над ним «Вы ответили: X», при повторной ошибке — ссылка «Перечитать раздел». После разбора — экран завершения с «Пройти тест заново» и тизером бонусного раунда (если он не разблокирован).
- **Бонусный тизер** показывается на экране завершения разбора, если `bonusEnabled: true` и финальный счёт основного теста < максимального.

---

## Последние значимые коммиты (состояние на 2026-04-23)

| Хеш | Что |
|---|---|
| `fix-audit` | fix(kdv): FAQPage JSON-LD синхронизирован с HTML-аккордеоном (4 из 8 ответов расходились); sitemap lastmod КДВ и главной → 2026-04-23; feed.xml lastBuildDate + КДВ pubDate → 2026-04-23; fix(js): overscrollBehavior:none добавлен в mod.07 openToc/closeToc; fix(css): color-mix fallback в breadcrumb separator |
| `fix-audit-2` | fix(js): стрый дублированный `/*` удалён в mod.16 site.js; BookmarkEngine.markCompleted() реализован в bookmark-engine.js (saved.completed+completedAt); fix(kdv): FAQPage JSON-LD синхронизирован с HTML-аккордеоном (8/8 ответов) |
| `fix-audit-3` | fix(html): id="section-label" aria-hidden добавлен во все 3 статьи (mod.06 section-label активирован); fix(sitemap): lastmod главной и КДВ → 2026-04-23 |
| `feat-ui` | feat(css): секция 40 — 5 универсальных UI-компонентов (stat-grid, compare-cards, pq-scripture, faq-accordion, summary-card); КДВ: stat-карточки в феномене, compare-cards Кумран/Наг-Хаммади, pull-quote цитаты Писания, анимированный FAQ, summary-card итога |
| `audit-3` | fix(audit): feed.xml lastBuildDate→Apr 18, krajne pubDate→Apr 1; twitter:image:alt добавлен в about; AGENTS бэклог #7/#20/#22 закрыты |
| `audit-2` | fix(audit): drop-cap исключён для Типа C; KDV section исправлен; headingAnchors/selectors добавлены в KDV config; README модули 21–27 добавлены; AGENTS бэклог синхронизирован |
| `audit-1` | fix(audit): Б1–Б6 HTML/CSS (barShareBtn, порядок bottom bar, skip-link, id=content, article-header--no-border, body id=top убран, TOC rail непрерывный) |
| `9a67164` | fix: тема кнопка выровнена по хлебным крошкам, запрещён inline top |
| `a33733b` | feat: тёмная тема по умолчанию |
| `9842641` | fix: восстановлен quiz launch overlay (КДВ) |
| `d2ed9d0` | fix: хлебные крошки — полный заголовок без обрезки |
| `00c2ade` | feat: drop-cap автоматически на первом абзаце каждой статьи |
| `bcdd1b1` | fix(audit): Б1–Б12 из audit-report.md (animateCount, qFocus, heart-flip, share score, aria-live, lightbox удалён) |
| `2acf881` | feat(share): российские сервисы (TG, VK, OK, WhatsApp, Копировать) |
| `v17` | feat(quiz): разбор ошибок после теста — Duolingo-паттерн (site.js v3 + css секция 39) |
| `v17` | refactor(quiz): полное кеширование DOM-refs, убраны getElementById внутри функций, прямые listeners вместо делегации |
| `v16` | feat(quiz): первая версия review-режима (исправлена в v17) |
| `a91f379` | fix(P0): критический SyntaxError в site.js — убивал весь JS |

---

## Бэклог задач

Список известных багов и улучшений. Перед началом работы проверить, что задача не уже сделана.

### 🔴 P0 — Критические баги

- [x] **#1 myth-bg в тёмной теме** — ✅ Закрыт: `--myth-bg: #1c1714; --myth-border: #3d2e25; --fact-bg: #141a18; --fact-border: #25382e` (css/site.css секция 02).
- [x] **#2 --muted контраст** — ✅ Закрыт: значение поднято до `#9ca3af` (6.8:1), css/site.css html.dark.
- [x] **#3 Quiz: подсветка ответов** — ✅ Закрыт: добавлены `--quiz-correct-bg/border`, `--quiz-wrong-bg/border` в html.dark (css/site.css секция 02).

### 🟠 P1 — Важные недоработки

- [x] **#5 Breadcrumb hover в тёмной теме** — ✅ Закрыт: `html.dark .breadcrumb__link:hover { color: var(--accent-strong); }` (css/site.css секция 06).
- [x] **#6 TOC rail непрерывный** — ✅ Закрыт: `border-left` на `nav`, `.toc-link { margin-left: -1px }` (css/site.css секция 15).
- [x] **#7 Sticky header без blur** — ✅ Закрыт: `.article-topnav` в `site.css` уже имеет `backdrop-filter: blur(12px)` через `@supports`; `.h-navbar.scrolled` в `home.css` — `blur(20px) saturate(160%)`.
- [x] **#8 Герменевтика без bottom-bar** — ✅ Закрыт: bottom bar присутствует во всех трёх статьях.
- [ ] **#9 Сноски: два формата** — КДВ использует `fn-ref` (модуль 12), Сердце/Герменевтика — `fn-marker` (модуль 20). Это **архитектурный выбор по типу статьи** (Тип A vs B/C), а не баг. Унификация возможна только при переписывании HTML всех статей. Оставить как есть до следующего крупного рефакторинга.
- [x] **#10 Share popup доступность** — ✅ Закрыт: `role="dialog"`, `aria-modal`, фокус-ловушка, `Esc` закрывает (js/site.js модуль 03).

### 🟡 P2 — Структурные улучшения

- [x] **#25 Quiz: разбор ошибок (Review mode)** — ✅ Закрыт v17: Duolingo-паттерн, накопление wrongAnswers[], режим review без изменений HTML, кнопка «Разобрать ошибки (N)», тизер бонусного раунда, fullRestart сбрасывает всё состояние.

- [ ] **#13 Title Case в JS** — модуль применяет title case к русскому тексту. Отключить для `:lang(ru)`.
- [x] **#16 Google Fonts без display=swap** — ✅ Закрыт: `&display=swap` добавлен во всех HTML-файлах.
- [x] **#17 Время чтения** — ✅ Закрыт: `page.readingTime` в SITE_CONFIG всех статей, JS читает через `SiteUtils.getConfig('page.readingTime', 10)` и отображает в `#btocTimeLeft`.
- [ ] **#18 lang на английских терминах** — скринридер читает с русским произношением. Оборачивать `<i lang="en">`.

### 🟢 P3 — Полировка

- [x] **#19 scroll-margin-top на якорях** — ✅ Закрыт: `--scroll-margin: 96px` в `:root`, `scroll-margin-top: var(--scroll-margin)`.
- [x] **#20 ::selection в тёмной теме** — ✅ Закрыт: `html.dark ::selection { background: #d4a574; color: #0e1116; }` в `css/site.css`.
- [x] **#22 Опечатки в КДВ** — ✅ Закрыт: «Мёртвого» и «Никейский собор» корректны во всём тексте статьи.
- [ ] **#23 `:hover` без `@media (hover: hover)`** — ~60 hover-правил в `css/site.css` не обёрнуты в `@media (hover: hover) and (pointer: fine)`. На iOS/Android после тапа элемент «застревает» в hover-состоянии (меняется фон, цвет или поднимается transform) до следующего тапа в другое место. **Почему не делаем сейчас:** риск велик — 60 правил, большой рефакторинг, легко случайно сломать стили; залипание заметно только там, где есть сильная смена фона или `transform: translateY`. `touch-action: manipulation` уже убрал 300ms delay. Делать отдельной задачей: пройти по всем `:hover` с `transform`, `background-color`, `color` и обернуть только их в `@media (hover: hover) and (pointer: fine)`.
- [ ] **#24 Footer** — минимальный/отсутствует. Добавить единый footer.
